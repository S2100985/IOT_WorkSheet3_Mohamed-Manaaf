# 21076191_Submission 3_IOT



## Name
Information Recording Desktop Application

## Description
This project is a desktop application that you can start running once you press the .jar file in the dist folder in the project file, once the program is opened you should see a view that can also be seen  on the screenshot attached to the program. from this GUI frame you can enter the required information like sensor information into the GUI screen and store all of it in a file. There is also an option (button) to load and display infromation in the system from a csv file. This can be used to add detailed sensor information and use it.

## Visuals
There is a screenshot of the popup attached to the project file.

## Installation
The project was done with the use of netbeans IDE.

## Support
You can use the internet for support

## Roadmap
No further releases are planned

## Project status
project status - it has been completed, there will be no further additions
